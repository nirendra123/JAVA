public class Animal {
    public void eat() {
        System.out.println("I am Eating");

    }
}
