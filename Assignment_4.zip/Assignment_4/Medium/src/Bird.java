public class Bird extends Animal {
    public void fly() {
        System.out.println("I am Flying");
    }
    public void walk(){
        System.out.println("I am walking");
    }
}
