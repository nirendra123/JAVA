public class Animal {
  public float eat() {
    System.out.println("I am Eating");

  }

}