public class Main {
    public static void main(String[] args) {
GUICounter guiCounter=new GUICounter();
guiCounter.increment();
guiCounter.decrement();

    }
}